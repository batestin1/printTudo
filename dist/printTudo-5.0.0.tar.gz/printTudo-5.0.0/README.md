
<h1 align="center">

<img src="https://img.shields.io/static/v1?label=PRINTTUDO%20POR&message=Bates&color=7159c1&style=flat-square&logo=ghost"/>

<h3> <p align="center">printTudo </p> </h3>

<h3> <p align="center"> ================= </p> </h3>

>> <h3> Resumo </h3>

<p> Imagine a seguinte situação: Você esta em uma aula, ou uma atividade, e necessita salvar os prints, mas infelizmente não tem tempo para isso. Este programa, ao executar, ele silenciosamente irá tirar prints para você no periodo de 8 horas. É mais do que suficiente para você colecionar um material digno de estudo. </p>

>> <h3> Como instalar </h3>

```
pip install printTudo

```
>> <h3> Como funciona </h3>

```
from printTudo import *

printTudo(x,y)

# o x indica a quantidade de prints que você deseja obter 
# o y indica a o intervalo de prints que você deseja obter

```
    